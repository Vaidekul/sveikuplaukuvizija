<?php

/**

 */
?>
<div>
	<?php

	echo do_shortcode( '[woocommerce_order_tracking]' );

	?>
</div>
